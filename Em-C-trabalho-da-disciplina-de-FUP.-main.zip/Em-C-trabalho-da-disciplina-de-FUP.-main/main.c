#include <stdio.h> // Biblioeteca da linguagem capaz de ler e imprimir.

//Dados selecionados
typedef struct {
    char nome[100];               // Nome do filme
    int ano_de_lancamento;        // Ano de lançamento
    int duracao_min;              // Duração (em minutos)
    float nota_imdb;              // Nota no IMDb
    float nota_rotten_tomatoes;   // Nota no Rotten Tomatoes
} Filme;

void opcao_1(Filme *f){

    printf("Qual o nome do filme?\n");
    scanf("%s", f->nome);

    printf("Em que ano foi lançado?\n");
    scanf("%d", &f->ano_de_lancamento);

    printf("Qual a duração, em minutos, do filme?\n");
    scanf("%d", &f->duracao_min);

    printf("Nota no IMDb:\n");
    scanf("%f", &f->nota_imdb);

    printf("Nota no Rotten Tomatoes:\n");
    scanf("%f", &f->nota_rotten_tomatoes);

}
void opcao_2(){

printf("Hora de mostrar seus filmes já assistidos!\n");

    for(int i = 0; i <  ){

        printf("O nome é: %s ")

    }

  //for(int i = 0; i < qtd_alunos; i++){
        //printf("Id: %d Idade: %d Ira: %f Nome: %s\n",//
       // alunos[i].id, alunos[i].idade, alunos[i].ira, alunos[i].nome);//

}
int main (){

    Filme f;

//Introdução.
printf("Olá, tudo bem, cinéfilos? Sejam muito bem-vindos! ");
printf("Esta é uma plataforma onde você consegue registrar algumas informações dos filmes que você tem assistido!\n");
printf("Vamos começar? Irei te direcionar ao Menu! :)\n");

// Menu.
printf("\nMenu:\n");
printf("[1] - Adicionar filme assistido\n");
printf("[2] - Listar filmes já assistidos\n");
printf("[3] - Remover filme da lista\n");
printf("[0] - Sair\n");

int opcao; // guardará a opcão do usuário.
scanf("%d", &opcao);

if(opcao == 1){
    opcao_1(&f);
}

    return 0;
}